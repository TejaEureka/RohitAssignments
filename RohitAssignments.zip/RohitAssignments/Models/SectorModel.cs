﻿using System;
namespace dotnet_jan_24_mac.Models
{
	public class SectorModel
	{
		public string SectorName { get; set; }
		public int SectorId { get; set; }
	}
}

