﻿using System;
namespace dotnet_jan_24_mac.Models
{
	public class StockModel
	{
		public string TickerSymbol { get; set; }
		public string TickerName { get; set; }


    }
}

