﻿using System;
namespace EnqueueValues
{
    class JoiningtheQueue
    {
        public Queue<string> waitingLine = new Queue<string>();

        public void ServiceQueue()
        {
            waitingLine = new Queue<string>();
        }

        public void EnqueuePerson(string people)
        {
            waitingLine.Enqueue(people);
        }

        public void DequeuePerson()
        {
            if (waitingLine.Count > 0)
            {
                string people = waitingLine.Dequeue();
                Console.WriteLine($"{people} has been served.");
                //DisplayQueue();
            }
            else
            {
                Console.WriteLine("The queue is empty. No one to dequeue.");
            }
        }

        public void DisplayQueue()
        {
            Console.WriteLine("Current Queue:");
            foreach (var people in waitingLine)
            {
                Console.Write($"{people} ");
            }
            Console.WriteLine();
        }
    }
}