﻿using System;
namespace FindlargestNum
{
    public class Fourth_solution
    {
        public void CompareTheNumbers()
        {
            Console.Write("Enter the 1st number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the 2nd number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 3rd number: ");
            int num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("The largest number is: " + num1);
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("The largest number is :" + num2);
            }
            else
            {
                Console.WriteLine("The largest number is :" + num3);
            }
        }
    }
}

