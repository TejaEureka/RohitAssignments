﻿using System;
namespace Equalornot;

public class First_solution
{
    public void CheckIfTwoNumbersAreEqual()
    {

        Console.Write("CheckIfTwoNumbersAreEqual(): ");

        Console.Write("Write the first integer: ");
        int num1 = Convert.ToInt32(Console.ReadLine());
        Console.Write("Write the second integer: ");
        int num2 = Convert.ToInt32(Console.ReadLine());
        if (num1 == num2)
        {
            Console.WriteLine("numbers are equal.");
        }
        else
        {
            Console.WriteLine("The numbers are not equal.");
        }
    }
}