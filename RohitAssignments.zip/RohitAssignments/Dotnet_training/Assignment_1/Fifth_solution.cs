﻿using System;
namespace Rollno
{
	public class Fifth_solution
	{
        public void CheckTheGrade()
		{
            Console.Write("Enter roll no: ");
            int rollNo = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter name: ");
            string name = Console.ReadLine();

            Console.Write("Enter marks for subject 1: ");
            int marks1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter marks for subject 2: ");
            int marks2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter marks for subject 3: ");
            int marks3 = Convert.ToInt32(Console.ReadLine());

            int total = marks1 + marks2 + marks3;
            double percentage = (double)total / 300 * 100;

            Console.WriteLine("Total marks: " + total);
            Console.WriteLine("Percentage: " + Math.Round(percentage, 2) + "%");

            if (percentage < 35)
            {
                Console.WriteLine("Grade: F");
            }
            else if (percentage >= 35 && percentage < 60)
            {
                Console.WriteLine("Grade: C");
            }
            else if (percentage >= 60 && percentage <= 80)
            {
                Console.WriteLine("Grade: B");
            }
            else
            {
                Console.WriteLine("Grade: A");
            }
        }
	}
}

