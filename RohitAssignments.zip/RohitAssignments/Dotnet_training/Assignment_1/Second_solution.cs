﻿using System;
namespace Positiveornot
{
	public class Second_solution
	{
		public void CheckItPositiveorNot()
		{
            Console.Write("Check Whether the Numberis positive or Not:");
            Console.Write("Enter a number: ");
            int num = Convert.ToInt32(Console.ReadLine());

            if (num > 0)
            {
                Console.WriteLine("The number is positive.");
            }
            else if (num < 0)
            {
                Console.WriteLine("The number is negative.");
            }
            else
            {
                Console.WriteLine("The number is zero.");
            }
        }
	}
}

