﻿using System;
namespace Height
{
	public class Third_solution
	{
        public void HeightCheck()
		{
            Console.Write("Enter person's height in CM: ");
            int height = Convert.ToInt32(Console.ReadLine());

            if (height < 60)
            {
                Console.WriteLine("The person is small.");
            }
            else if (height >= 60 && height < 160)
            {
                Console.WriteLine("The person is medium.");
            }
            else
            {
                Console.WriteLine("The person is tall.");
            }
        }
	}
}

