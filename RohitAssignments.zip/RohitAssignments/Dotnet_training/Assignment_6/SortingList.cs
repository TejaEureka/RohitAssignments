﻿using System;
//SortedList
//Create a program that uses a SortedList to store the names and ages of five people.
//Allow the user to input names and ages for each person.
//Display the names and ages in ascending order based on age.
//Allow the user to search for a person by name and display their age.

namespace EnteringValues
{
    public class SortingList
    {
        public void SortingTheNames()
        {
            SortedList<string, int> person = new SortedList<string, int>();

            for (int i = 0; i < 5; i++)
            {
                Console.Write("Enter name: ");
                string name = Console.ReadLine();

                Console.Write("Enter age: ");
                int age = Convert.ToInt32(Console.ReadLine());

                person.Add(name, age);
            }

            Console.WriteLine("\nNames and ages in ascending order based on age:");
            foreach (KeyValuePair<string, int> names in person)
            {
                Console.WriteLine("{0} ({1})", names.Key, names.Value);
            }
            Console.Write("\nEnter name to search: ");
            string searchName = Console.ReadLine();

            if (person.ContainsKey(searchName))
            {
                Console.WriteLine("{0}'s age is {1}", searchName, person[searchName]);
            }
            else
            {
                Console.WriteLine("{0} not found", searchName);
            }
        }
    }
}

