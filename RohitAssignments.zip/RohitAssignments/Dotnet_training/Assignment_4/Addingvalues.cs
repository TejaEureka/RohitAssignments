﻿using System;
namespace UserString
{
	public class Addingvalues
	{
		public void EnterTheString()
        {
            //Accept a string input from the user.
            Console.WriteLine("Enter the string:");
            string userInput = Console.ReadLine();

            //Display the length of the input string.
            int length = userInput.Length;
            Console.WriteLine("Length of the input string:" + length);

            // Convert the input string to uppercase and display it
            string uppercase = userInput.ToUpper();
            Console.WriteLine("Uppercased string :" + uppercase);

            // Check if the input string contains the word "CSharp" (case-insensitive) and display the result
            Console.WriteLine("Is string contains CSharp: " + userInput.Contains("CSharp"));

            // Replace all occurrences of the letter 'a' in the string with '*'
            string replacedString = userInput.Replace("a", "*");
            Console.WriteLine($"String after replacing 'a' with '*': {replacedString}");

            // Display the input string in reverse order
            char[] charArray = userInput.ToCharArray();
            Array.Reverse(charArray);
            string reversedString = new string(charArray);
            Console.WriteLine($"Reversed string: {reversedString}");

            // Count and display the number of vowels in the string
            int vowelCount = 0;
            foreach (char c in charArray)
            {
                if ("aeiou".Contains(c))
                {
                    vowelCount++;
                }
            }
            Console.WriteLine("Number of vowels in the string:" + vowelCount);
        }
	}
}


