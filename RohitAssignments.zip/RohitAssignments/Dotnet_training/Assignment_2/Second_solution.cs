﻿using System;
//Write a program to display first 100 numbers which are divisible by 5 using loops.
namespace Divisiblebyfive
{
	public class Second_solution_1
	{
		public void NumbersAreDivisibleby5()
		{
            int count = 0;
            for (int i = 0; count < 100; i++)
            {
                if (i % 5 == 0)
                {
                    Console.WriteLine($"Number:" + i);
                    count++;
                }
            }
        }
	}
}

