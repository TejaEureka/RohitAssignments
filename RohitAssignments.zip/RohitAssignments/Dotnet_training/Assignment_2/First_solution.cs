﻿using System;
//Print Days of Week using for loop and display should be in format example "Monday : 2".


namespace Displaydayno
{
	public class First_solution_1
	{
        public void DisplayTheDayandNumber()
		{
            string[] daysOfWeek = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
            int[] dayNumbers = { 0, 1, 2, 3, 4, 5, 6 };

            for (int i = 0; i < daysOfWeek.Length; i++)
            {
                Console.WriteLine($"{daysOfWeek[i]}: {dayNumbers[i]}");
            }
        }
	}
}

