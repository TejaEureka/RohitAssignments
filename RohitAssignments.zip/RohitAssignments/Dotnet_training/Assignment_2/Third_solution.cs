﻿using System;
//Write a program to print EVEN numbers as well odd number and count of even and odd for fist 500 numbers.
namespace EvenorOdd
{
	public class Third_solution_1
	{
        public void CheckedTheNumber()
		{
            int Even = 0;
            int Odd = 0;

            for (int i = 1; i <= 500; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine($"EVEN: {i}");
                    Even++;
                }
                else
                {
                    Console.WriteLine("ODD:" + i);
                    Odd++;
                }
            }

            Console.WriteLine($"Count of EVEN numbers: {Even}");
            Console.WriteLine($"Count of ODD numbers: {Odd}");
        }
	}
}

