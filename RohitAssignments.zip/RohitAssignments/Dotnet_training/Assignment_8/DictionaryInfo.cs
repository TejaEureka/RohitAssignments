﻿using System;
using Microsoft.VisualBasic;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Numerics;
using System.Xml.Linq;

//Dictionary
//Create a program that uses a Dictionary to store contact information (name and phone number) for five people.Allow the user to
//input names and phone numbers for each person. Display the contact information for a person based on their name.
//Allow the user to search for a person by name and display their phone numb
namespace DictionaryInfo
{
	public class Dictionary
	{
        public Dictionary<string, string> contactDictionary = new Dictionary<string, string>();
        public void ContactManager()
            {
                contactDictionary = new Dictionary<string, string>();
            }


            public void AddContact(string name, string phoneNumber)
            {
                contactDictionary[name] = phoneNumber;
                DisplayContacts();
            }

            public void DisplayContacts()
            {
                Console.WriteLine("Contact Information:");

                foreach (var contact in contactDictionary)
                {
                    Console.WriteLine($"Name: {contact.Key}, Phone Number: {contact.Value}");
                }
            }

            public void SearchContactByName(string name)
            {
                if (contactDictionary.ContainsKey(name))
                {
                string phoneNumber = contactDictionary[name];
                Console.WriteLine($"{name}'s phone number is: {phoneNumber}");
            }
            else
            {
                Console.WriteLine($"{name} not found in the contact list.");
            }
        }
    }
}



