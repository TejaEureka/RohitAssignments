﻿using System;
using Dotnet_training;
using FindlargestNum;
using Equalornot;
using Positiveornot;
using Height;
using Rollno;
using Displaydayno;
using Divisiblebyfive;
using EvenorOdd;
using ProgressReport;
using UserString;
using AreaofCircle;
using AreaofRectangle;
using Dotnet_training.Assignment_5;
using EnteringValues;
namespace Dotnet_training;
using EnqueueValues;
using DictionaryInfo;

public class Program
{

    public static void Main()
    {

        //First_solution first_Solution = new First_solution();
        //first_Solution.CheckIfTwoNumbersAreEqual();

        //Second_solution second_Solution = new Second_solution();
        //second_Solution.CheckItPositiveorNot();

        //Third_solution third_Solution = new Third_solution();
        //third_Solution.HeightCheck();

        //Fourth_solution fourth_Solution = new Fourth_solution();
        //fourth_Solution.CompareTheNumbers();

        //Fifth_solution fifth_Solution = new Fifth_solution();
        //fifth_Solution.CheckTheGrade();

        //First_solution_1 first_Solution_1 = new First_solution_1();
        //first_Solution_1.DisplayTheDayandNumber();

        //Second_solution_1 second_Solution_1 = new Second_solution_1();
        //second_Solution_1.NumbersAreDivisibleby5();

        //Third_solution_1 third_Solution_1 = new Third_solution_1();
        //third_Solution_1.CheckedTheNumber();

        //Student_Grades student_Grades = new Student_Grades();
        //student_Grades.GetTheReports();

        //Addingvalues addingvalues = new Addingvalues();
        //addingvalues.EnterTheString();

        //Circle circle = new Circle(5);
        //Rectangle rectangle = new Rectangle(4.7, 9.3);

        //circle.PrintAreaDetails();
        //rectangle.PrintAreaDetails();

        //SortingList sortingList = new SortingList();
        //sortingList.SortingTheNames();

        
        JoiningtheQueue joiningtheQueue = new JoiningtheQueue();
        while (true)
        {
            Console.WriteLine("\nOptions:");
            Console.WriteLine("1. Enqueue (Join the line)");
            Console.WriteLine("2. Dequeue (Get service)");
            Console.WriteLine("3. Exit");

            Console.Write("Enter your choice (1-3): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter the name to enqueue: ");
                    string enqueueName = Console.ReadLine();
                    joiningtheQueue.EnqueuePerson(enqueueName);
                    break;

                case 2:
                    joiningtheQueue.DequeuePerson();
                    break;

                case 3:
                    Console.WriteLine("Exiting the program.");
                    return;

                default:
                    Console.WriteLine("Invalid choice. Please enter a valid option.");
                    break;
            }
           

        }
        /*Dictionary dictionary = new Dictionary();

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"Enter the name of person {i + 1}: ");
            string name = Console.ReadLine();

            Console.Write($"Enter the phone number for {name}: ");
            string phoneNumber = Console.ReadLine();

            dictionary.AddContact(name, phoneNumber);
        }

        Console.Write("\nEnter the name to search: ");
        string searchName = Console.ReadLine();
        dictionary.SearchContactByName(searchName);
        */
    }
}
    

    




