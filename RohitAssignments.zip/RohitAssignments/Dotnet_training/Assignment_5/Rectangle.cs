﻿using System;
using Dotnet_training.Assignment_5;
namespace AreaofRectangle
{
	public class Rectangle : Shape
    {
        public double Length { get; set; }
        public double Width { get; set; }

        public Rectangle(double length, double width)
        {
            Length = length;
            Width = width;
        }

        public override double CalculationArea()
        {
            return Length * Width;
        }
    }

}

