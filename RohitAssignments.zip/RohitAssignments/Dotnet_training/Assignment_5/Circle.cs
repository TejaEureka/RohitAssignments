﻿using System;
using Dotnet_training.Assignment_5;
namespace AreaofCircle
{
    public class Circle : Shape
    {
        public double Radius { get; set; }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public override double CalculationArea()
        {
            return Math.PI * Radius * Radius;
        }
    }
}


