﻿using System;
using AreaofRectangle;
using AreaofCircle;
//Create a base class called Shape with a virtual method CalculateArea() that returns a double. 
//Create two derived classes: Circle and Rectangle, both inheriting from the Shape class. 
//In each derived class, override the CalculateArea() method to provide specific implementations
//for calculating the area of a circle and a rectangle, respectively. 
//Create a method called PrintAreaDetails() in the base class that prints the details of the shape,
//including its type and area. 
//In the Main method of your program, create instances of both the Circle and Rectangle classes.
//Call the PrintAreaDetails() method on each instance to demonstrate polymorphic behavior.

namespace Dotnet_training.Assignment_5
{
    public class Shape
    {
        public virtual double CalculationArea()
        {
            return 0.0;
        }
        public void PrintAreaDetails()
        {
            Console.WriteLine($"Shape Type: {this.GetType().Name}");
            Console.WriteLine($"Area: {CalculationArea()}");
            Console.WriteLine();
        }
    }

}






