﻿using System;
using static System.Formats.Asn1.AsnWriter;

namespace ProgressReport
{
	public class Student_Grades
	{
        string[] studentNames = new string[5];
        List<int> studentScores = new List<int>();
        public void FindName()
        {
            string searchName = Console.ReadLine();
            bool found = false;
            for (int i = 0; i < studentNames.Length; i++)
            {
                if (studentNames[i] == searchName)
                {
                    Console.WriteLine($"{studentNames[i]}: {studentScores[i]}");
                    found = true;
                }

            }

            if (found == false)
            {
                Console.WriteLine($"The {searchName} is not found");
                FindName();
            }
        }
		public void GetTheReports()
		{
            
            Console.WriteLine("Enter the names of 5 students:");
            for (int i = 0; i < 5; i++)
            {
                studentNames[i] = Console.ReadLine();
            }
            // Create a list to store the scores of each student
            

            // Allow the user to input scores for each student
            for (int i = 0; i < studentNames.Length; i++)
            {
                Console.Write($"Enter the score for {studentNames[i]}: ");
                //int studentScores = Convert.ToInt32(Console.ReadLine());
                if (int.TryParse(Console.ReadLine(), out int score))
                {
                    studentScores.Add(score);
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer score.");
                    i--;
                }
            }
            
            double averageScore = studentScores.Average();
            Console.WriteLine($"The average score of all students is: {averageScore}");

                Console.WriteLine("Student scores:");
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine($"{studentNames[i]}: {studentScores[i]}");
                }

            Console.WriteLine("Search for a student by name:");
            FindName();





















            //    string searchName = Console.ReadLine();
            //    int? searchScore = studentNames.Select((name, index) => new { name, score = studentScores[index] }).FirstOrDefault(x => x.name == searchName)?.score;

            //    if (searchScore != null)
            //    {
            //    Console.WriteLine($"{searchName}'s score is:" + searchScore);
            //}
            //else
            //{
            //        Console.WriteLine($"Student '{searchName}' not found.");
            //}
            //int index = Array.IndexOf(names, searchName, StringComparer.OrdinalIgnoreCase);
            //if (index != -1 && index < scores.Count)
            //{
            //    Console.WriteLine($"Score of {searchName}: {scores[index]}");
            //}
            //else
            //{
            //    Console.WriteLine($"Student with name '{searchName}' not found.");
            //}
        }
	}
}

